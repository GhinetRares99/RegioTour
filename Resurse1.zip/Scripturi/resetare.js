document.getElementById("btn_resetare").onclick=function(){
		
  document.getElementById("i_activ").checked = false;
  document.getElementById("i_pret").value = 100;
  document.getElementById("i_pret_select").checked = true;
  document.getElementById("i_zona").selectedIndex = 0;
  document.getElementById("i_luna").selectedIndex = 0;
  document.getElementById("i_words").value = "";
  
};
	

