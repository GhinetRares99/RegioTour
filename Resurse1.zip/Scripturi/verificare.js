function validare(){
	var x=document.forms["form_inreg"]["parola"].value;
	var y=document.forms["form_inreg"]["rparola"].value;

	if(x!=y){
		alert("Parolele nu coincid!");
		return false;
	}

	
}