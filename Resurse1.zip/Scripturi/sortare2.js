window.onload=function(){
	document.getElementById("btn_sort_2").onclick=function(){

		var packs = document.getElementsByClassName("pachet_t");
		var v_packs = Array.from(packs);
		v_packs.sort(function(a,b){

			return b.getElementsByClassName("p_name").innerHTML.localeCompare(a.getElementsByClassName("p_name").innerHTML);
		});
		
		for(let i=0; i<v_packs.length;i++){
			v_packs[i].style.order=i;
		}
		
	}
	
	
}