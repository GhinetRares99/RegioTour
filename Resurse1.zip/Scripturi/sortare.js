window.onload=function(){
	document.getElementById("btn_sort").onclick=function(){

		var packs = document.getElementsByClassName("pachet_t");
		var v_packs = Array.from(packs);
		v_packs.sort(function(a,b){

			return a.getElementsByClassName("p_name").innerHTML.localeCompare(b.getElementsByClassName("p_name").innerHTML);
		});
		
		for(let i=0; i<v_packs.length;i++){
			v_packs[i].style.order=i;
		}
		
	}
	
	
}