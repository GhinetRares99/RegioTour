window.onload=function(){
	
	var linkuriMeniu=document.querySelectorAll("ul.menu a");
	var locatie=window.location.pathname;
	var lochash=window.location.hash;
	locatie=(locatie=="/") ? "/index" : locatie;
	for(var link of linkuriMeniu){
		link.style.backgroundColor="lightgreen";
		if(link.href.endsWith(locatie)){
			link.style.backgroundColor="burlywood";
		}
		
		
		link.onclick=function(){
			var chMenu=document.getElementById("ch-menu");
			chMenu.checked=false;
			
			///locatie.scrollIntoView({behavior:"smooth"});

		}
		
		/*
		var linkuriInterne=document.querySelectorAll("ul.menu a[href*='#']");
		console.log(linkuriInterne.length);
		
		for (var lnk of linkuriInterne){
			var paghref=lnk.href.substring(lnk.href.lastIndexOf("/"),lnk.href.lastIndexOf("#"));
			var locationhref=window.location.href;
			var paglocation=locationhref.substring(locationhref.lastIndexOf("/"),locationhref.lastIndexOf("#"));
			if(paglocation==paghref)
			  lnk.onclick=clickLink
		}
		*/
       
	}
	


	
	
/*
var idIntervalPlimbare=-1;
function clickLink(ev){
	ev.preventDefault();
	
	clearInterval(idIntervalPlimbare)
	var ch;
	var lnk=ev.target;
	if(lnk.parentNode.parentNode.classList.contains("submeniu")){
		var checkboxes=document.getElementByClassName("ch-submenu");
		for(ch of checkboxes)
		{
			ch.checked=false;
		}
		document.getElementById("ch-menu").checked=false;
		
	}
	else if(lnk.parentNode.parentNode.classList.contains("menu")){
		document.getElementById("ch-menu").checked=false;
	}
	
	var coordScroll;
	var poz=lnk.href.indexOf("#");
	var idElemScroll=lnk.href.substring(poz+1);
	if(idElemScroll==""){
		coordScroll=0;
	}
	else{
		coordScroll=getOffsetTop(document.getElementById(idElemScroll));
	}
	var distanta=coordScroll-document.documentElement.scrollTop;
	console.log(distanta);
	pas=distanta<0 ?-20:20;
	
	idIntervalPlimbare=setInterval(plimba,10,pas,coordScroll,lnk.href.substring(lnk.href.lastIndexOf("#")+1));
	
}

function getOffsetTop(elem){
	var rez=elem.offsetTop;
	while(elem.offsetParent && elem.offsetParent != document.body){
		elem = elem.offsetParent;
		rez+=elem.offsetTop;
	}
	return rez;
}

function plimba(pas,coordScroll, href){
	scrollVechi=document.documentElement.scrollTop;
	document.documentElement.scrollTop+=pas;
	if(pas>0 && coordScroll<=document.documentElement.scrollTop || pas<0 && coordScroll>=document.documentElement.scrollTop || scrollVechi==documentElement.scrollTop){
		clearInterval(idIntervalPlimbare);
		window.location.hash=href;
	}
	
}
*/	
	
	
};

