let darkMode = window.localStorage.getItem("darkMode");	
if(darkMode === "enabled"){
	enableDarkMode();
}


const darkModeToggle = document.querySelector("#theme_button");

	
function enableDarkMode(){
	document.body.classList.add("dark");
	window.localStorage.setItem("darkMode","enabled");
}
	
function disableDarkMode(){
	document.body.classList.remove("dark");
	window.localStorage.setItem("darkMode","disabled");
}
	
darkModeToggle.addEventListener("click", () => {
	darkMode = window.localStorage.getItem("darkMode");
	if(darkMode !== "enabled") {
		enableDarkMode();
			
	} else {
		disableDarkMode();
	}
});
	
	
