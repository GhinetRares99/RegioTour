window.onload=function(){
	
	var total = 0;
	document.getElementById("btn_filtrare").onclick=function(){
		var activ_on = document.getElementById("i_activ").checked;
		var prt_max = parseInt(document.getElementById("i_pret").value);
	    var prt_check = document.getElementById("i_pret_select_2").checked;
		var e = document.getElementById("i_zona");
		var txt = document.getElementById("i_words").value;
	    var ln = document.getElementById("i_luna").options;
		var sir="";
	    for(let opt of ln){
			if(opt.selected)
			{
				sir+=opt.value+" ";
			}
		}
		   
	
		var produse = document.querySelectorAll("#obiecte article");
		console.log(produse.length);
		for(var pack of produse){
			pack.style.display="block";
			
			var active = pack.getElementsByClassName("caract_booleana")[0];
			/*console.log(active);*/
			var pret = parseInt(pack.getElementsByClassName("caract_numerica")[0].innerHTML);
			var zona = pack.getElementsByClassName("caract_categorie")[0].innerHTML;
			var nm = pack.getElementsByClassName("p_name")[0].innerHTML;
			var luna = pack.getElementsByClassName("caract_data")[0].innerHTML;
			
			var conditie1 = activ_on && active.innerHTML=="Nu";
			var conditie2 = (pret > prt_max) && prt_check;
			var conditie3 = e.selectedIndex != 0 && e.options[e.selectedIndex].innerHTML != zona;
			var conditie4 = txt != "" && nm.includes(txt)==0;
			var conditie5 = sir.includes("Nimic")==0 && sir.includes(luna)==0;
			
			
			total = total + pret;
			var conditie_totala = conditie1 || conditie2 || conditie3 || conditie4 || conditie5;
			if(conditie_totala){
				pack.style.display="none";
				total = total - pret;
			}

			
		}
		
	};
	document.getElementById("btn_calculare").onclick=function(){
		if(total == 0){
			alert("Nu au fost selectate pachete turistice!");
			document.getElementById("tot").innerHTML = total;
		}
		
		else {
			document.getElementById("tot").innerHTML = total;
			total=0;
		}
	}
    
	
	
}